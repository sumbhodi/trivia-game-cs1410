package triviaGame;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages the logic of our Quiz, 
 * updating the questions, score, name, and avater.
 * @author Cooper & James
 */
public class QuizManager 
{
	List<Question> questions = new ArrayList<>();
	List<ScoreEntry> highScores = new ArrayList<>();
	private int currentIndex;
	int tries;
	private int score;
	String playerName;
	String playerAvatar;
	
	/**
	 * Creates a QuizManager while assigning questionFile
	 * and scoreFile.
	 * @param questionFile
	 * @param scoreFile
	 */
	public QuizManager(String questionFile, String scoreFile)
	{
		questions = FileHandler.readQuestions(questionFile);
		//highScores = FileHandler.readHighScores(scoreFile);
	}
	
	/**
	 * Starts the game and assigns name, and avatar.
	 * While also shuffling the questions.
	 * @param name
	 * @param avatar
	 */
	public void start(String name, String avatar)
	{
		this.playerName = name;
		this.playerAvatar = avatar;
		
		score = 0;
		currentIndex = 0;
		Collections.shuffle(questions);
	}
	
	/**
	 * If there is another question it
	 * returns the next question.
	 * @return
	 */
	public Question getQuestion()
	{
		if(hasNext()) 
		{
			return questions.get(currentIndex);
		}
		return null;
	} 
	
	/**
	 * Returns if the choice was correct
	 * while updating the score correctly:
	 * First guess: +4
	 * Second guess: +2
	 * Third guess: +1
	 * @param choice
	 * @return
	 */
	public boolean answer(int choice)
	{
		if(!hasNext())
		{
			return false;
		}
		else
		{
			if(tries == 0)
			{
				score += 4;
			}
			else if (tries == 1)
			{
				score += 2;
			}
			else if (tries == 2)
			{
				score += 1;
			}

			currentIndex++;
			return questions.get(currentIndex).isCorrectChoice(choice);
		}
		
	}
	
	/**
	 * Checks if there is another question.
	 * @return
	 */
	public boolean hasNext()
	{
		return currentIndex < questions.size();
	}
	
	/**
	 * Returns the score.
	 * @return
	 */
	public int getScore()
	{
		return score;
	}
	
	/**
	 * Returns highScores
	 * @return highScores
	 */
	public List<ScoreEntry> getHighScore()
	{
		return highScores;
	}
	
	/**
	 * Saves the highscore in txt.
	 */
	public void saveScore()
	{
		//FileHandler.writeHighScores();
	}
}
