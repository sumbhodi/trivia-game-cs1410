package triviaGame;

public class ScoreEntry 
{
	
}
